Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 10
Server version: 5.6.16 MySQL Community Server (GPL)

Copyright (c) 2000, 2014, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> create database sailor;
Query OK, 1 row affected (0.00 sec)

mysql> create table sailor(sail_id primary key,sail_name varchar(50),age int); 
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'primary key,sail_name varchar(50),age int)' at line 1
mysql> use sailor;
Database changed
mysql> create table sailor(sail_id primary key,sail_name varchar(50),age int); 
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'primary key,sail_name varchar(50),age int)' at line 1
mysql> create table sailor(sail_id int primary key,sail_name varchar(50),age int); 
Query OK, 0 rows affected (0.54 sec)

mysql> create table bot_reserve(boat_id int primary key,boat_name varchar(50),boat_colour varchar(50),sail_id int,foreign key(sail_id) references sailor(sail_id));
Query OK, 0 rows affected (1.08 sec)

mysql> show tables;
+------------------+
| Tables_in_sailor |
+------------------+
| bot_reserve      |
| sailor           |
+------------------+
2 rows in set (0.00 sec)

mysql> desc sailor;
+-----------+-------------+------+-----+---------+-------+
| Field     | Type        | Null | Key | Default | Extra |
+-----------+-------------+------+-----+---------+-------+
| sail_id   | int(11)     | NO   | PRI | NULL    |       |
| sail_name | varchar(50) | YES  |     | NULL    |       |
| age       | int(11)     | YES  |     | NULL    |       |
+-----------+-------------+------+-----+---------+-------+
3 rows in set (0.11 sec)

mysql> desc bot_reserve;
+-------------+-------------+------+-----+---------+-------+
| Field       | Type        | Null | Key | Default | Extra |
+-------------+-------------+------+-----+---------+-------+
| boat_id     | int(11)     | NO   | PRI | NULL    |       |
| boat_name   | varchar(50) | YES  |     | NULL    |       |
| boat_colour | varchar(50) | YES  |     | NULL    |       |
| sail_id     | int(11)     | YES  | MUL | NULL    |       |
+-------------+-------------+------+-----+---------+-------+
4 rows in set (0.01 sec)

mysql> drop bot_reserver;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bot_reserver' at line 1
mysql> drop table bot_reserver;
ERROR 1051 (42S02): Unknown table 'sailor.bot_reserver'
mysql> drop table bot_reserve;
Query OK, 0 rows affected (0.22 sec)

mysql> create table boat_reserve(boat_id int primary key,boat_name varchar(50),boat_colour varchar(50),sail_id int,foreign key(sail_id) references sailor(sail_id));
Query OK, 0 rows affected (0.62 sec)

mysql> desc boat_reserve;
+-------------+-------------+------+-----+---------+-------+
| Field       | Type        | Null | Key | Default | Extra |
+-------------+-------------+------+-----+---------+-------+
| boat_id     | int(11)     | NO   | PRI | NULL    |       |
| boat_name   | varchar(50) | YES  |     | NULL    |       |
| boat_colour | varchar(50) | YES  |     | NULL    |       |
| sail_id     | int(11)     | YES  | MUL | NULL    |       |
+-------------+-------------+------+-----+---------+-------+
4 rows in set (0.08 sec)

mysql> insert into sailor values(1,"mahesh",21);
Query OK, 1 row affected (0.48 sec)

mysql> insert into sailor values(2,"litty",40);
Query OK, 1 row affected (0.12 sec)

mysql> insert into sailor values(3,"godwin",8);
Query OK, 1 row affected (0.13 sec)

mysql> insert into sailor values(4,"bibin",28);
Query OK, 1 row affected (0.49 sec)

mysql> insert into sailor values(5,"nandhana",50);
Query OK, 1 row affected (0.41 sec)

mysql> insert into sailor values(6,"alan",26);
Query OK, 1 row affected (0.07 sec)

mysql> select*from sailor;
+---------+-----------+------+
| sail_id | sail_name | age  |
+---------+-----------+------+
|       1 | mahesh    |   21 |
|       2 | litty     |   40 |
|       3 | godwin    |    8 |
|       4 | bibin     |   28 |
|       5 | nandhana  |   50 |
|       6 | alan      |   26 |
+---------+-----------+------+
6 rows in set (0.00 sec)

