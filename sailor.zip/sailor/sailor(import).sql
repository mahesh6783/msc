-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2023 at 03:33 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sailor`
--

-- --------------------------------------------------------

--
-- Table structure for table `boat_reserve`
--

CREATE TABLE IF NOT EXISTS `boat_reserve` (
  `boat_id` int(11) NOT NULL,
  `boat_name` varchar(50) DEFAULT NULL,
  `boat_colour` varchar(50) DEFAULT NULL,
  `sail_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`boat_id`),
  KEY `sail_id` (`sail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sailor`
--

CREATE TABLE IF NOT EXISTS `sailor` (
  `sail_id` int(11) NOT NULL,
  `sail_name` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`sail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sailor`
--

INSERT INTO `sailor` (`sail_id`, `sail_name`, `age`) VALUES
(1, 'mahesh', 21),
(2, 'litty', 40),
(3, 'godwin', 8),
(4, 'bibin', 28),
(5, 'nandhana', 50),
(6, 'alan', 26);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `boat_reserve`
--
ALTER TABLE `boat_reserve`
  ADD CONSTRAINT `boat_reserve_ibfk_1` FOREIGN KEY (`sail_id`) REFERENCES `sailor` (`sail_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
