-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 06, 2023 at 06:20 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `supplier_product`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `pr_id` int(11) NOT NULL,
  `pr_name` varchar(50) DEFAULT NULL,
  `sno` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`pr_id`),
  KEY `sno` (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pr_id`, `pr_name`, `sno`, `quantity`, `price`) VALUES
(100, 'camera', 4, 10, 1000),
(101, 'computer', 2, 25, 1500),
(102, 'mouse', 2, 29, 2900),
(103, 'projector', 3, 5, 8000),
(104, 'keybord', 5, 35, 1200),
(105, 'SSD', 1, 35, 14000);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
  `sno` int(11) NOT NULL,
  `sname` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `phone_no` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`sno`, `sname`, `city`, `phone_no`) VALUES
(1, 'intel', 'coimbatore', '9945342378'),
(2, 'dell', 'kottayam', '8896745673'),
(3, 'epson', 'mumbai', '6745348945'),
(4, 'nikon', 'kochi', NULL),
(5, 'viewsonic', 'dulhi', '8956347845');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`sno`) REFERENCES `supplier` (`sno`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
