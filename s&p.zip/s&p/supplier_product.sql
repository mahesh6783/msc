Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 1
Server version: 5.6.16 MySQL Community Server (GPL)

Copyright (c) 2000, 2014, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> create database supplier_product;
Query OK, 1 row affected (0.10 sec)

mysql> use supplier_product;
Database changed
mysql> create table supplier(sno primary key,sname varchar(50),city varchar(50),phone_no decimal);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'primary key,sname varchar(50),city varchar(50),phone_no decimal)' at line 1
mysql> create table supplier(sno primary key,sname varchar(50),city varchar(50),phone_no desimal);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'primary key,sname varchar(50),city varchar(50),phone_no desimal)' at line 1
mysql> create table supplier(sno primary key,sname varchar(50),city varchar(50),phone_no decimal(10));
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'primary key,sname varchar(50),city varchar(50),phone_no decimal(10))' at line 1
mysql> create table supplier(sno primary key,sname varchar(50),city varchar(50),phone_no decimal(12.0));
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'primary key,sname varchar(50),city varchar(50),phone_no decimal(12.0))' at line 1
mysql> create table supplier(sno primary key,sname varchar(50),city varchar(50),phone_no int);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'primary key,sname varchar(50),city varchar(50),phone_no int)' at line 1
mysql> create table supplier(sno int primary key,sname varchar(50),city varchar(50),phone_no decimal(10));
Query OK, 0 rows affected (0.78 sec)

mysql> create table product(pr_id int primary key,pr_name varchar(50),sno int,quantity int,price int,foregin key(sno) references supplier(sno));
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key(sno) references supplier(sno))' at line 1
mysql> create table product(pr_id int primary key,pr_name varchar(50),sno int,quantity int,price int,foreign key(sno) references supplier(sno));
Query OK, 0 rows affected (1.01 sec)

mysql> desc product;
+----------+-------------+------+-----+---------+-------+
| Field    | Type        | Null | Key | Default | Extra |
+----------+-------------+------+-----+---------+-------+
| pr_id    | int(11)     | NO   | PRI | NULL    |       |
| pr_name  | varchar(50) | YES  |     | NULL    |       |
| sno      | int(11)     | YES  | MUL | NULL    |       |
| quantity | int(11)     | YES  |     | NULL    |       |
| price    | int(11)     | YES  |     | NULL    |       |
+----------+-------------+------+-----+---------+-------+
5 rows in set (0.01 sec)

mysql> desc supplier;
+----------+---------------+------+-----+---------+-------+
| Field    | Type          | Null | Key | Default | Extra |
+----------+---------------+------+-----+---------+-------+
| sno      | int(11)       | NO   | PRI | NULL    |       |
| sname    | varchar(50)   | YES  |     | NULL    |       |
| city     | varchar(50)   | YES  |     | NULL    |       |
| phone_no | decimal(10,0) | YES  |     | NULL    |       |
+----------+---------------+------+-----+---------+-------+
4 rows in set (0.02 sec)

mysql> insert into supplier values(1,"intel","coimbatore",9945342378);
Query OK, 1 row affected (0.47 sec)

mysql> select*from supplier;
+-----+-------+------------+------------+
| sno | sname | city       | phone_no   |
+-----+-------+------------+------------+
|   1 | intel | coimbatore | 9945342378 |
+-----+-------+------------+------------+
1 row in set (0.00 sec)

mysql> insert into supplier values(2"dell","kottayam",8896745673);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"dell","kottayam",8896745673)' at line 1
mysql> insert into supplier values(2,"dell","kottayam",8896745673);
Query OK, 1 row affected (0.15 sec)

mysql> insert into supplier values(3,"epson","mumbai",6745348945);
Query OK, 1 row affected (0.44 sec)

mysql> insert into supplier values(4,"nikon","kochi",null);
Query OK, 1 row affected (0.47 sec)

mysql> insert into supplier values(5,"viewsonic","dulhi",8956347845);
Query OK, 1 row affected (0.48 sec)

mysql> select*from supplier;
+-----+-----------+------------+------------+
| sno | sname     | city       | phone_no   |
+-----+-----------+------------+------------+
|   1 | intel     | coimbatore | 9945342378 |
|   2 | dell      | kottayam   | 8896745673 |
|   3 | epson     | mumbai     | 6745348945 |
|   4 | nikon     | kochi      |       NULL |
|   5 | viewsonic | dulhi      | 8956347845 |
+-----+-----------+------------+------------+
5 rows in set (0.00 sec)

mysql> desc product;
+----------+-------------+------+-----+---------+-------+
| Field    | Type        | Null | Key | Default | Extra |
+----------+-------------+------+-----+---------+-------+
| pr_id    | int(11)     | NO   | PRI | NULL    |       |
| pr_name  | varchar(50) | YES  |     | NULL    |       |
| sno      | int(11)     | YES  | MUL | NULL    |       |
| quantity | int(11)     | YES  |     | NULL    |       |
| price    | int(11)     | YES  |     | NULL    |       |
+----------+-------------+------+-----+---------+-------+
5 rows in set (0.30 sec)

mysql> insert into product values(100,camera,4,10,1000);
ERROR 1054 (42S22): Unknown column 'camera' in 'field list'
mysql> insert into product values(100,"camera",4,10,1000);
Query OK, 1 row affected (0.12 sec)

mysql> insert into product values(101,"computer",2,25,1500);
Query OK, 1 row affected (0.49 sec)

mysql> insert into product values(102,"mouse",2,29,2900);
Query OK, 1 row affected (0.46 sec)

mysql> insert into product values(103,"projector",3,5,8000);
Query OK, 1 row affected (0.52 sec)

mysql> insert into product values(104,"keybord",5,35,1200);
Query OK, 1 row affected (0.45 sec)

mysql> insert into product values(105,"SSD",1,35,14000);
Query OK, 1 row affected (0.49 sec)

mysql> select*from product;
+-------+-----------+------+----------+-------+
| pr_id | pr_name   | sno  | quantity | price |
+-------+-----------+------+----------+-------+
|   100 | camera    |    4 |       10 |  1000 |
|   101 | computer  |    2 |       25 |  1500 |
|   102 | mouse     |    2 |       29 |  2900 |
|   103 | projector |    3 |        5 |  8000 |
|   104 | keybord   |    5 |       35 |  1200 |
|   105 | SSD       |    1 |       35 | 14000 |
+-------+-----------+------+----------+-------+
6 rows in set (0.00 sec)

