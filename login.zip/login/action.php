<?php
session_start();

$con=mysql_connect("localhost","root","")or die("error");
mysql_select_db("login",$con)or die("error");

$name=$_POST['user'];
$password=$_POST['pass'];

$sql="SELECT id FROM `login_tbl` WHERE uname='$name' AND pass='$password'";

$query=mysql_query($sql);

$result=mysql_num_rows($query);

if($result==0)
{
    echo "invalid username and password";
}
else if($result==1)
{
    // echo "hi";
    $user_id=mysql_fetch_array($query);
    $_SESSION['user_id'] = $user_id[0];
    header('location: session.php');
 }
?>