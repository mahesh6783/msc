<html>
    <form action="action.php" method="POST">
        USERNAME: <input type="text" name="user">
        PASSWORD: <input type="text" name="pass">
        <input type="submit" >
</html>