<?php
require 'sessionaction.php';
$con=mysql_connect("localhost","root","")or die("error");
mysql_select_db("login",$con)or die("error");

if(login())
{
    echo" you are logged in";
}
else
{
    include 'index.php';
}
?>