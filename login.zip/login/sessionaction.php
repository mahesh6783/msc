<?php
ob_start();
session_start();
// echo $_SESSION['user_id'];

function login()
{
    if(isset($_SESSION['user_id']) && !empty($_SESSION['user_id']))
    {
        return true;
    }
    else
    {
        return false;
    }
}
?>