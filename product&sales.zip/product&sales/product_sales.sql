Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 2
Server version: 5.6.16 MySQL Community Server (GPL)

Copyright (c) 2000, 2014, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> use product_sales;
Database changed
mysql> create table product(pno int primary key,pname varchar(50),quantity int,unit_price int);
Query OK, 0 rows affected (0.80 sec)

mysql> desc product;
+------------+-------------+------+-----+---------+-------+
| Field      | Type        | Null | Key | Default | Extra |
+------------+-------------+------+-----+---------+-------+
| pno        | int(11)     | NO   | PRI | NULL    |       |
| pname      | varchar(50) | YES  |     | NULL    |       |
| quantity   | int(11)     | YES  |     | NULL    |       |
| unit_price | int(11)     | YES  |     | NULL    |       |
+------------+-------------+------+-----+---------+-------+
4 rows in set (0.01 sec)

mysql> create table sales(order_no int,quantity
    -> ;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
mysql> create table sales(order_no int primary key,quantity_ordered int,pno int,foregin key(pno)references 
    -> ;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key(pno)references' at line 1
mysql> create table sales(order_no int primary key,quantity_ordered int,pno int,foregin key(pno)references product(pno));
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key(pno)references product(pno))' at line 1
mysql> create table sales(order_no int primary key,quantity_ordered int,pno int,foreign key(pno)references product(pno));
Query OK, 0 rows affected (0.85 sec)

mysql> desc sales;
+------------------+---------+------+-----+---------+-------+
| Field            | Type    | Null | Key | Default | Extra |
+------------------+---------+------+-----+---------+-------+
| order_no         | int(11) | NO   | PRI | NULL    |       |
| quantity_ordered | int(11) | YES  |     | NULL    |       |
| pno              | int(11) | YES  | MUL | NULL    |       |
+------------------+---------+------+-----+---------+-------+
3 rows in set (0.01 sec)

mysql> insert into product values(500,"pen",8,50);
Query OK, 1 row affected (1.86 sec)

mysql> insert into product values(505,"milch",2,5000);
Query OK, 1 row affected (1.80 sec)

mysql> insert into product values(510,"dvd",2,6000);
Query OK, 1 row affected (0.44 sec)

mysql> insert into product values(515,"flash drive",40,1000);
Query OK, 1 row affected (0.54 sec)

mysql> insert into product values(520,"paper",400,1050);
Query OK, 1 row affected (0.40 sec)

mysql> insert into product values(525,"watch",4,3000);
Query OK, 1 row affected (0.19 sec)

mysql> insert into product values(530,"tv",6,9000);
Query OK, 1 row affected (0.47 sec)

mysql> select*from product;
+-----+-------------+----------+------------+
| pno | pname       | quantity | unit_price |
+-----+-------------+----------+------------+
| 500 | pen         |        8 |         50 |
| 505 | milch       |        2 |       5000 |
| 510 | dvd         |        2 |       6000 |
| 515 | flash drive |       40 |       1000 |
| 520 | paper       |      400 |       1050 |
| 525 | watch       |        4 |       3000 |
| 530 | tv          |        6 |       9000 |
+-----+-------------+----------+------------+
7 rows in set (0.00 sec)

mysql> desc sale;
ERROR 1146 (42S02): Table 'product_sales.sale' doesn't exist
mysql> desc sales;
+------------------+---------+------+-----+---------+-------+
| Field            | Type    | Null | Key | Default | Extra |
+------------------+---------+------+-----+---------+-------+
| order_no         | int(11) | NO   | PRI | NULL    |       |
| quantity_ordered | int(11) | YES  |     | NULL    |       |
| pno              | int(11) | YES  | MUL | NULL    |       |
+------------------+---------+------+-----+---------+-------+
3 rows in set (0.01 sec)

mysql> insert into sales values(300,20,500);
Query OK, 1 row affected (0.52 sec)

mysql> insert into sales values(356,5,530);
Query OK, 1 row affected (0.21 sec)

mysql> insert into sales values(400,3,525);
Query OK, 1 row affected (0.19 sec)

mysql> insert into sales values(450,2,520);
Query OK, 1 row affected (0.53 sec)

mysql> insert into sales values(1000,5,515);
Query OK, 1 row affected (0.46 sec)

mysql> insert into sales values(5001,9,505);
Query OK, 1 row affected (0.13 sec)

mysql> insert into sales values(5010,4,505);
Query OK, 1 row affected (0.22 sec)

mysql> select*from sales;
+----------+------------------+------+
| order_no | quantity_ordered | pno  |
+----------+------------------+------+
|      300 |               20 |  500 |
|      356 |                5 |  530 |
|      400 |                3 |  525 |
|      450 |                2 |  520 |
|     1000 |                5 |  515 |
|     5001 |                9 |  505 |
|     5010 |                4 |  505 |
+----------+------------------+------+
7 rows in set (0.00 sec)

